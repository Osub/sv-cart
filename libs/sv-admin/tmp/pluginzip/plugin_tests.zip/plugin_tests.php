<?	header("Content-Type: text/html; charset=utf-8");
	$data=array(
		"name"=>"插件测试实例",
		"directory"=>"插件测试实例",
		"copyright"=>"© 2009 上海实玮网络科技有限公司 版权所有",
		"version"=>"1.1.0",
		"code"=>"plugin_test",
		"author"=>"http://www.seevia.cn",
		"install"=>"ucenter_sql/install.sql",
		"uninstall"=>"ucenter_sql/uninstall.sql",
		"function"=>array(
			"/libs/sv-admin/plugins/test/",
		),
		"contents"=>array(
			"plugin_tests/controllers/plugin_tests_controller.php"=>"../libs/sv-admin/controllers/plugin_tests_controller.php",		
			"plugin_tests_sql"=>"../pluginsql/plugin_tests_sql/"
		),
		"app_contents"=>array(
			"/libs/sv-admin/controllers/",
		)
	);
	echo json_encode($data);
	$aa = json_decode(json_encode($data), true);
	echo "<pre>";
	print_r(json_decode(json_encode($data)));
?>

